<?php

namespace App\Http\Controllers;

use App\Models\CategoryAdmin;
use Illuminate\Http\Request;

class CategoryAdminController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $categories = CategoryAdmin::all();
        return view('__categoryAdmin/categoryAdmin', ['categories'=>$categories]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('__categoryAdmin/categoryAdminCreate');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
//        dd($request);
        CategoryAdmin::create([
            "name" => $request->name,
            "description" => $request->description,
        ]);

        $categories = CategoryAdmin::all();
        return view('__categoryAdmin/categoryAdmin', ['categories'=>$categories]);
    }

    /**
     * Display the specified resource.
     */
    public function show(CategoryAdmin $categoryAdmin)
    {
        dd(111);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
//        dd(111);
        $categoryAdmin = CategoryAdmin::find($id);

        return view('__categoryAdmin/categoryAdminRead', ['categoryAdmin'=>$categoryAdmin]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $categoryAdmin = CategoryAdmin::find($id);
        $categoryAdmin->name = $request->name;
        $categoryAdmin->description = $request->description;
        $categoryAdmin->save();

        $categories = CategoryAdmin::all();
        return view('__categoryAdmin/categoryAdmin', ['categories'=>$categories]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
//        dd(111);
        $categoryAdmin = CategoryAdmin::find($id);
        $categoryAdmin->delete();

        $categories = CategoryAdmin::all();
        return view('__categoryAdmin/categoryAdmin', ['categories'=>$categories]);
    }
}

//
//
//
//namespace App\Http\Controllers;
//
//use App\Models\Category;
//use App\Models\CategoryAdmin;
//use Illuminate\Http\Request;
//
//class CategoryController extends Controller
//{
//    /**
//     * Display a listing of the resource.
//     */
//    public function index()
//    {
////        dd(111);
//        $categories = Category::all();
//        return view('__categoryAdmin', ['categories' => $categories]);
//    }
//
//    /**
//     * Show the form for creating a new resource.
//     */
//    public function create()
//    {
//        return view('categoryAdminCreate');
//    }
//
//    /**
//     * Store a newly created resource in storage.
//     */
//    public function store(Request $request)
//    {
//        //dd($request);
//        Category::create([
//            "name" => $request->name,
//            "description" => $request->description,
//        ]);
//
//        $categories = Category::all();
//        return view('__categoryAdmin', ['categories' => $categories]);
//    }
//
//    /**
//     * Display the specified resource.
//     */
//    public function show(string $id)
//    {
//        dd(111);
//    }
//
//    /**
//     * Show the form for editing the specified resource.
//     */
//    public function edit(string $id)
//    {
//        $category = Category::find($id);
//
//        return view('categoryAdminRead', ['category' => $category]);
//    }
//
//    /**
//     * Update the specified resource in storage.
//     */
//    public function update(Request $request, string $id)
//    {
//        $category = Category::find($id);
//        $category->name = $request->name;
//        $category->description = $request->description;
//        $category->save();
//        $categories = Category::all();
//        return view('__categoryAdmin', ['categories' => $categories]);
//    }
//
//    /**
//     * Remove the specified resource from storage.
//     */
//    public function destroy(string $id)
//    {
//        $category = Category::find($id);
//        $category->delete();
//
//        $categories = Category::all();
//        return view('__categoryAdmin', ['categories' => $categories]);
//    }
//}
