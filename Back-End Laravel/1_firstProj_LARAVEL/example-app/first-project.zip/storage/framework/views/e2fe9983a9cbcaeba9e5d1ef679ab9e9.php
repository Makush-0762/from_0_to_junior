<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row h-100">
            <div class="col-3">
                <div class="card p-4" style="width: 18rem;border-radius:  25%">
                    <img src="https://cs7.pikabu.ru/post_img/2018/01/05/10/1515172208178355173.jpg" class="card-img-top" style="border-radius:  25%" alt="...">
                    <div class="card-body">
                        <h5 class="card-title text-center"><strong>Bober BobroBcbkuy</strong></h5><hr>
                        <h5 class="card-title text-center"><strong>GOD of FullStack Developer</strong></h5><hr>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <div class="mt-3 d-flex justify-content-center"><button type="button" class="btn btn-primary">Redacte</button></div>
                    </div>
                </div>
            </div>
            <div class="col-8 bg-white p-4 h-100" >
                <p> New role</p>







                <form action="<?php echo e(route('role.update', ['id'=>$role->id])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>

                    <input type="radio" name="role" value="user" id="user" <?php echo e($role->name == 'user' ? 'checked' : ''); ?>>
                    <label for="user">User</label>

                    <input type="radio" name="role" value="moderator" id="moderator" <?php echo e($role->name == 'moderator' ? 'checked' : ''); ?>>
                    <label for="moderator">Moderator</label>

                    <button type="submit">Go</button>
                </form>
            </div>
        </div>
        <div class="col-1"></div>
    </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\laravel\example-app\resources\views/__roleAdmin/roleAdminEdit.blade.php ENDPATH**/ ?>
