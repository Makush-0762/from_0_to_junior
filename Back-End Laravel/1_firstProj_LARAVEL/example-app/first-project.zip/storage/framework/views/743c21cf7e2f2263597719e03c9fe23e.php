<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row h-100">
            <div class="col-1"></div>
            <div class="col-10 bg-white p-4 h-100" >
                <p> category </p>

                <form action="<?php echo e(route('__categoryAdmin.update', ['id'=>$categoryAdmin->id])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <input type="text" name="name" value="<?php echo e($categoryAdmin->name); ?>">
                    <input type="text" name="description" value="<?php echo e($categoryAdmin->description); ?>">
                    <button type="submit" >Go</button>
                </form>
            </div>
        </div>
        <div class="col-1"></div>
    </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\laravel\example-app\resources\views/categoryAdminRead.blade.php ENDPATH**/ ?>
