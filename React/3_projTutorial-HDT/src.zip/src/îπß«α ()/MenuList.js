// import React, {useState, useEffect, useRef} from "react";
// import './Menu.css'
// // import NavDropdown from 'react-bootstrap-v5/lib/NavDropdown';

// export default function MenuList (){
//     const [showDropdown, setShowDropdown] = useState(false);
//     const dropdownRef = useRef();

//     function toggleDropdown() {
//         setShowDropdown(!showDropdown);                                 
//     }

//     useEffect(() => {                               //На цей код особо не дивіться він злизаний, спішив не було 
//         function handleClickOutside(event) {        //часу розбиратись, з Ref-фми тре більше часу пропрацювати щоб самому таке написати
//           if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
//             setShowDropdown(false);
//           }
//         }
//         document.addEventListener("mousedown", handleClickOutside);
//         return () => {
//           document.removeEventListener("mousedown", handleClickOutside);
//         };
//       }, [dropdownRef]);
//     return(
//         <>
//         <div className="bodyMunyList">
//             <ul className="MemuList">
//                 <li><a href="#" className="listHome"><strong>Home</strong></a></li>
//                 <li class="dropdown"><a href="#" onClick={toggleDropdown} className="dropbtn"><strong>Tutorial&nbsp;⊽</strong></a>
//                     <span ref={dropdownRef} id="dropdown" className={`dropdown-content ${showDropdown ? 'show' : ''}`}>
//                         <a href="#" >HTML</a>
//                         <a href="#" >CSS</a>
//                         <a href="#" >JavaScript</a>
//                     </span>
//                 </li>
//             </ul>
//         </div>

//         </>
//     )

// }