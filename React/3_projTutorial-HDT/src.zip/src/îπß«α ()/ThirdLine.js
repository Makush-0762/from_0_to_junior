// import React from "react";
// import Thirdline from "../images/Group 1.png"

// export default function ThirdLine (){

//     return(
//         <>
//             <div style={{textAlign:"center", fontFamily:'Montserrat, sans-serif'}}>
//                 <img src={Thirdline} alt="ThirdLine"/>
//             </div>
//         </>
//     )
// }