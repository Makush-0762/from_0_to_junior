import React from "react";
import LogoH from "../../images/Asset 4х2x.png"

export default function Logo (){

    return(
        <>
            <div className="logocent">
                <a href="/#"><img src={LogoH} alt="LogoH" style={{width: '38px'}}/></a>
            </div>
        </>
    )
}