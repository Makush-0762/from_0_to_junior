import React from "react";

export default function Copyright (){

    return(
        <>
            <p style={{textAlign:'center', color: '#fff', padding: '0', margin:'0'}}>&copy; 2023 How Do This (Fucker of the Russian Federation)</p>
        </>
    )
}