import React from "react";
import './SupportLinck.css'
import Logo from "./Logo"


export default function SupportLinck (){

    return(

        <>

            <div className="bodySupportlink">
                <Logo />
                <a href="#" className="supportlink">support@gmial.com</a>
                <a href="#" className="supportlink">support@gmial.com</a>
                <a href="#" className="supportlink">support@gmial.com</a>
            </div>
        </>
    )
}