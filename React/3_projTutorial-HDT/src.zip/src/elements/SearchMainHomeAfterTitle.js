
import React from "react";


export default function SearchMainHomeAfterTitle (){

    return(
        <>
            <div style={{textAlign:"center", fontFamily:'Montserrat, sans-serif', marginTop: '40px'}}>
                <p style={{fontSize: '20px'}}>Or maybe you wanted to learn a language from scratch?</p>
            </div>
        </>
    )
}