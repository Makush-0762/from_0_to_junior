<>
                
              <div className="body-footer__bottom">
                <div className="body-footer__rules">
                  Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ipsa odit vel quam unde, esse consequuntur
                  quas totam sed deleniti rem nisi, id aliquam magnam? Maxime, nisi! Doloribus ducimus adipisci
                  voluptates? Lorem ipsum dolor, sit amet consectetur adipisicing elit. Pariatur ducimus, laborum eos
                  dicta sunt atque dolore nesciunt aliquid. Unde harum dolorum non sint nisi cupiditate illo
                  consequatur, sit perspiciatis iusto?
                </div>
                <div className="body-footer__copy">
                  <span>www.shop.com ©</span>
                </div>
              </div>
</>