import React from "react";


export default function ImgcCard({url, text, width}) {

    return (
        <>
            <div className="bodyCardImg">
                <img src='https://book24.ua/upload/iblock/0ce/0ceedcfa2fcec18cec183207360e4305.jpg' className="cardImg" alt='CardImg' />
            </div>
        </>
    )
}