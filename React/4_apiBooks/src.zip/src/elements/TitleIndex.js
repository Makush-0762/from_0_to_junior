import React from "react";

export default function TitleIndex() {

    return (
        <>
            <div>
                <span className="titleIndex">BOOK <br/> YOU</span>
            </div>
        </>
    )
}