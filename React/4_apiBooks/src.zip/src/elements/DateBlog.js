import React from "react";

export default function DateBlog (){

    return(
        <>
            <span style={{color:'rgba(15, 0, 225, 1)'}}>12.05.2023</span>
        </>
    )
}