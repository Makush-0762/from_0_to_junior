import React from "react";


export default function Icon() {

    return (
        <>
            Icon
        </>
    )
}