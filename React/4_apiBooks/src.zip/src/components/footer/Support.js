import React from "react";
import { Link } from "react-router-dom";

export default function Support() {

    return (
        <>
            <div className="bodySupport">
                <Link to={'/'}><p>suppfsdort@gmil.com</p></Link>
                <Link to={'/'}><p>+38067-124-872</p></Link>
                <Link to={'/'}><p>suppsfdsort@gmil.com</p></Link>
                <Link to={'/'}><p>+38067-124-872</p></Link>
                <Link to={'/'}><p>supsdfsport@gmil.com</p></Link>
                <Link to={'/'}><p>+38067-124-872</p></Link>
            </div>
        </>
    )
}