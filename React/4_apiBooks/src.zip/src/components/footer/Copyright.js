import React from "react";

export default function Copyright (){

    return(
        <>
            <p style={{textAlign:'center', color: '#000', padding: '0', margin:'0'}}>&copy; 2023 BOOK4YOU (Fucker of the Russian Federation)</p>
        </>
    )
}